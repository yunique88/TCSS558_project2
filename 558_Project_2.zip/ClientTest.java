public class ClientTest {
	/**
	 * Args are ignored here, null host resolves to localhost
	 * @param theArgs
	 */
	public static void main(String[] theArgs) {
			String[] args = new String[2];
			args[0] = null;
			
			args[1] = "1";
			new KeyValueClient().main(args);
			args[1] = "2";
			new KeyValueClient().main(args);
			args[1] = "3";
			new KeyValueClient().main(args);
			args[1] = "4";
			new KeyValueClient().main(args);
			args[1] = "5";
			new KeyValueClient().main(args);
			args[1] = "6";
			new KeyValueClient().main(args);
			args[1] = "7";
			new KeyValueClient().main(args);
			args[1] = "8";
			new KeyValueClient().main(args);
	}
}