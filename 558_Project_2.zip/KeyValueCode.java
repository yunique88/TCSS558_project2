/**
 * An enum to hold server codes
 * @author Dave K.
 */
public enum KeyValueCode {PUT, GET, GET_KEY_MISSING, DELETE, 
		DELETE_KEY_MISSING
}
